import { Button } from "@/components/ui/button";
import { ArrowRight, Download, Play, CheckCircle } from "lucide-react";
import heroImage from "@/assets/hero-medical-transformation.jpg";

const HeroSection = () => {
  return (
    <section className="relative pt-24 pb-16 lg:pt-32 lg:pb-24 bg-gradient-hero overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-primary-light/20 to-transparent"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="animate-fade-in">
            {/* Badge */}
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-success/10 text-success border border-success/20 mb-6">
              <CheckCircle className="w-4 h-4 mr-2" />
              <span className="text-sm font-medium">Trusted by 50,000+ Medical Students</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-6">
              From{" "}
              <span className="bg-gradient-primary bg-clip-text text-transparent">
                Foreign Graduate
              </span>{" "}
              to{" "}
              <span className="bg-gradient-primary bg-clip-text text-transparent">
                Licensed Doctor
              </span>
            </h1>

            {/* Subheadline */}
            <p className="text-xl lg:text-2xl text-muted-foreground leading-relaxed mb-8">
              Master FMGE 2025 with India's Most Comprehensive Question Bank -{" "}
              <span className="text-primary font-semibold">6000+ Previous Year Questions</span>
            </p>

            {/* Key Benefits */}
            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {[
                "FMGE-Specific Content Only",
                "Proven Success Methodology",
                "Subject-wise Organization",
                "Mobile + Web Access"
              ].map((benefit, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-success flex-shrink-0" />
                  <span className="text-foreground font-medium">{benefit}</span>
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button 
                size="lg" 
                className="bg-gradient-primary text-primary-foreground hover:shadow-elevated transition-all duration-300 group"
              >
                Start Your FMGE Journey - Free Trial
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground group"
              >
                <Download className="w-5 h-5 mr-2" />
                Download ReflexFMGE App
              </Button>
            </div>

            {/* Social Proof */}
            <div className="flex items-center space-x-6 text-muted-foreground">
              <div className="flex items-center space-x-2">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="w-8 h-8 rounded-full bg-gradient-primary border-2 border-background"></div>
                  ))}
                </div>
                <span className="text-sm">Join thousands of successful students</span>
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative lg:animate-float">
            <div className="relative rounded-2xl overflow-hidden shadow-elevated">
              <img
                src={heroImage}
                alt="Medical transformation from foreign graduate to licensed doctor"
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/10 to-transparent"></div>
            </div>
            
            {/* Floating stats cards */}
            <div className="absolute -top-4 -left-4 bg-card rounded-xl p-4 shadow-card border border-border animate-scale-in">
              <div className="text-2xl font-bold text-primary">6000+</div>
              <div className="text-sm text-muted-foreground">FMGE Questions</div>
            </div>
            
            <div className="absolute -bottom-4 -right-4 bg-card rounded-xl p-4 shadow-card border border-border animate-scale-in">
              <div className="text-2xl font-bold text-success">15-20%</div>
              <div className="text-sm text-muted-foreground">Pass Rate</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;