import { Button } from "@/components/ui/button";
import { Mail, Phone, MapPin, Download } from "lucide-react";

const Footer = () => {
  const quickLinks = [
    "Features",
    "Plans", 
    "Testimonials",
    "Why Choose Us",
    "Blogs",
    "Sign In",
    "FMGE Preparation Tips",
    "Previous Year Questions",
    "Mock Tests"
  ];

  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <h3 className="text-2xl font-bold mb-4 bg-gradient-primary bg-clip-text text-transparent">
              Reflex
            </h3>
            <p className="text-background/80 text-sm leading-relaxed mb-6">
              India's premier FMGE preparation platform with a focus on high-yield previous year questions and comprehensive practice tests for Foreign Medical Graduates.
            </p>
          </div>

          {/* Contact Information */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-background">Contact</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <Mail className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                <div>
                  <div className="text-background/90 text-sm">supportfmge@reflexprep.com</div>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Phone className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                <div>
                  <div className="text-background/90 text-sm">+91-7835083689</div>
                  <div className="text-background/60 text-xs">10 AM–8 PM, All Days</div>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <MapPin className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                <div className="text-background/90 text-sm">
                  S-15, 2nd Floor, Uphar Cinema Market, Green Park Extension, New Delhi, 110016
                </div>
              </div>
            </div>
          </div>

          {/* App Download Section */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-background">Download</h4>
            <p className="text-background/80 text-sm mb-4">
              Get our app for a better experience on mobile
            </p>
            <div className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start bg-transparent border-background/20 text-background hover:bg-background/10"
              >
                <Download className="w-4 h-4 mr-2" />
                Google Play
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start bg-transparent border-background/20 text-background hover:bg-background/10"
              >
                <Download className="w-4 h-4 mr-2" />
                App Store
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-background">Quick Links</h4>
            <div className="grid grid-cols-1 gap-2">
              {quickLinks.map((link, index) => (
                <a
                  key={index}
                  href="#"
                  className="text-background/80 hover:text-background transition-colors duration-200 text-sm py-1"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-background/20 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-background/60 text-sm mb-4 md:mb-0">
              © 2025 Reflex. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-background/80 hover:text-background transition-colors duration-200">
                Terms of Use
              </a>
              <a href="#" className="text-background/80 hover:text-background transition-colors duration-200">
                Privacy Policy
              </a>
              <a href="#" className="text-background/80 hover:text-background transition-colors duration-200">
                Refund Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;