import { Button } from "@/components/ui/button";
import { CheckCircle, X, Crown, Zap, Target } from "lucide-react";
import { cn } from "@/lib/utils";

const PricingSection = () => {
  const plans = [
    {
      name: "Basic",
      icon: Target,
      price: "₹1,999",
      period: "/month",
      description: "Perfect for getting started with FMGE preparation",
      features: [
        "2000+ Previous Year Questions",
        "Subject-wise Practice Tests",
        "Basic Performance Analytics",
        "Mobile App Access",
        "Email Support",
        "Study Progress Tracking"
      ],
      notIncluded: [
        "Full Mock Tests",
        "Detailed Explanations",
        "Expert Doubt Resolution",
        "Advanced Analytics"
      ],
      buttonText: "Start Basic Plan",
      popular: false,
      gradient: "from-muted to-muted/80"
    },
    {
      name: "Premium",
      icon: Crown,
      price: "₹3,999",
      period: "/month",
      description: "Most popular choice for serious FMGE aspirants",
      features: [
        "6000+ Previous Year Questions",
        "All Subject-wise Tests",
        "Full-length Mock Tests",
        "Detailed Question Explanations",
        "Advanced Performance Analytics",
        "Mobile + Web Access",
        "Priority Email Support",
        "Weak Area Identification",
        "Study Plan Recommendations",
        "Offline Question Download"
      ],
      notIncluded: [
        "One-on-One Mentoring",
        "Live Doubt Sessions"
      ],
      buttonText: "Choose Premium",
      popular: true,
      gradient: "from-primary to-accent"
    },
    {
      name: "Pro",
      icon: Zap,
      price: "₹6,999",
      period: "/month", 
      description: "Complete FMGE mastery with expert guidance",
      features: [
        "All Premium Features",
        "One-on-One Mentoring (2 sessions/month)",
        "Live Expert Doubt Resolution",
        "Custom Study Plans",
        "FMGE Strategy Sessions",
        "Previous Year Paper Analysis",
        "Personalized Weak Area Focus",
        "24/7 Chat Support",
        "Mock Interview Sessions",
        "FMGE Success Roadmap",
        "Early Access to New Content"
      ],
      notIncluded: [],
      buttonText: "Go Pro",
      popular: false,
      gradient: "from-accent to-primary"
    }
  ];

  return (
    <section id="plans" className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-primary/10 text-primary border border-primary/20 mb-6">
            <Crown className="w-4 h-4 mr-2" />
            <span className="text-sm font-medium">Choose Your FMGE Success Plan</span>
          </div>
          
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Affordable Plans for{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Every FMGE Aspirant
            </span>
          </h2>
          
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            From basic practice to complete FMGE mastery - choose the plan that fits your preparation needs and budget
          </p>

          {/* Money Back Guarantee */}
          <div className="inline-flex items-center space-x-2 bg-success/10 text-success px-4 py-2 rounded-full border border-success/20">
            <CheckCircle className="w-4 h-4" />
            <span className="text-sm font-medium">7-Day Money Back Guarantee</span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {plans.map((plan, index) => (
            <div 
              key={index}
              className={cn(
                "relative bg-card rounded-2xl shadow-soft border transition-all duration-300 hover:shadow-card",
                plan.popular ? "border-primary shadow-card scale-105" : "border-border"
              )}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-primary text-primary-foreground px-6 py-2 rounded-full text-sm font-semibold shadow-soft">
                    Most Popular
                  </div>
                </div>
              )}

              <div className="p-8">
                {/* Plan Header */}
                <div className="text-center mb-8">
                  <div className={cn(
                    "w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center",
                    `bg-gradient-to-br ${plan.gradient}`
                  )}>
                    <plan.icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <h3 className="text-2xl font-bold text-foreground mb-2">
                    {plan.name}
                  </h3>
                  
                  <p className="text-muted-foreground text-sm mb-4">
                    {plan.description}
                  </p>
                  
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-foreground">
                      {plan.price}
                    </span>
                    <span className="text-muted-foreground ml-2">
                      {plan.period}
                    </span>
                  </div>
                </div>

                {/* Features List */}
                <div className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                      <span className="text-foreground text-sm">{feature}</span>
                    </div>
                  ))}
                  
                  {plan.notIncluded.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start space-x-3 opacity-50">
                      <X className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                      <span className="text-muted-foreground text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <Button 
                  className={cn(
                    "w-full",
                    plan.popular 
                      ? "bg-gradient-primary text-primary-foreground hover:shadow-elevated" 
                      : "border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                  )}
                  variant={plan.popular ? "default" : "outline"}
                  size="lg"
                >
                  {plan.buttonText}
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="bg-secondary/30 rounded-2xl p-8 lg:p-12">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Why Choose ReflexFMGE Plans?
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-foreground">FMGE-Specific Content</div>
                    <div className="text-muted-foreground text-sm">Every question is curated specifically for FMGE exam patterns</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-foreground">Flexible Cancellation</div>
                    <div className="text-muted-foreground text-sm">Cancel anytime, no questions asked</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-foreground">International Access</div>
                    <div className="text-muted-foreground text-sm">Study from anywhere in the world</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center lg:text-right">
              <div className="text-3xl font-bold text-primary mb-2">15-20%</div>
              <div className="text-muted-foreground mb-4">Current FMGE Pass Rate</div>
              
              <div className="text-3xl font-bold text-success mb-2">85%+</div>
              <div className="text-muted-foreground">ReflexFMGE Student Success Rate</div>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold text-foreground mb-8">
            Frequently Asked Questions
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6 text-left">
            <div className="bg-card rounded-xl p-6 shadow-soft border border-border">
              <h4 className="font-semibold text-foreground mb-2">Can I switch plans anytime?</h4>
              <p className="text-muted-foreground text-sm">Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately.</p>
            </div>
            
            <div className="bg-card rounded-xl p-6 shadow-soft border border-border">
              <h4 className="font-semibold text-foreground mb-2">Is there a free trial?</h4>
              <p className="text-muted-foreground text-sm">Yes, we offer a 7-day free trial for all plans so you can experience the full ReflexFMGE platform.</p>
            </div>
            
            <div className="bg-card rounded-xl p-6 shadow-soft border border-border">
              <h4 className="font-semibold text-foreground mb-2">What payment methods do you accept?</h4>
              <p className="text-muted-foreground text-sm">We accept all major credit/debit cards, UPI, net banking, and international payment methods.</p>
            </div>
            
            <div className="bg-card rounded-xl p-6 shadow-soft border border-border">
              <h4 className="font-semibold text-foreground mb-2">Do you offer student discounts?</h4>
              <p className="text-muted-foreground text-sm">Yes, we offer special discounts for students. Contact our support team with your student ID for more information.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;