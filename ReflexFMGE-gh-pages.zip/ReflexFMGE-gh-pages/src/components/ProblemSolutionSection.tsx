import { AlertTriangle, CheckCircle, Target, BookOpen, Users, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

const ProblemSolutionSection = () => {
  const problems = [
    {
      icon: AlertTriangle,
      title: "Feeling stuck after completing MBBS abroad?",
      description: "Your degree isn't recognized until you pass FMGE"
    },
    {
      icon: TrendingUp,
      title: "Frustrated with FMGE's low 15-20% pass rate?",
      description: "Most students struggle without proper guidance"
    },
    {
      icon: BookOpen,
      title: "Struggling to find FMGE-specific preparation resources?",
      description: "Generic medical prep doesn't match FMGE patterns"
    },
    {
      icon: Users,
      title: "Watching Indian MBBS peers start practicing?",
      description: "While you're still preparing for qualification"
    }
  ];

  const solutions = [
    {
      icon: Target,
      title: "6000+ Previous Year FMGE Questions",
      description: "Comprehensive question bank with detailed explanations",
      highlight: "Most Comprehensive"
    },
    {
      icon: BookOpen,
      title: "FMGE-Specific Content Only",
      description: "No irrelevant material - focus only on what matters",
      highlight: "Laser Focused"
    },
    {
      icon: CheckCircle,
      title: "Proven Success Methodology",
      description: "Same approach that helped NEET PG students succeed",
      highlight: "Battle Tested"
    },
    {
      icon: Users,
      title: "Subject-wise Organization",
      description: "Organized approach covering all 19 medical subjects",
      highlight: "Systematic"
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Problems Section */}
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            We Understand Your{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">Challenges</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            As a Foreign Medical Graduate, you face unique obstacles that others don't understand
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {problems.map((problem, index) => (
            <div 
              key={index} 
              className="bg-card rounded-xl p-6 shadow-soft border border-border hover:shadow-card transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center mb-4">
                <problem.icon className="w-6 h-6 text-destructive" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {problem.title}
              </h3>
              <p className="text-muted-foreground text-sm">
                {problem.description}
              </p>
            </div>
          ))}
        </div>

        {/* Solutions Section */}
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Here's How We{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">Help You Succeed</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            ReflexFMGE is specifically designed to address every challenge you face
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {solutions.map((solution, index) => (
            <div 
              key={index} 
              className="bg-card rounded-xl p-6 shadow-soft border border-border hover:shadow-card transition-all duration-300 group animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors duration-300">
                  <solution.icon className="w-6 h-6 text-primary" />
                </div>
                <div className="absolute -top-2 -right-2 bg-accent text-accent-foreground text-xs px-2 py-1 rounded-full font-medium">
                  {solution.highlight}
                </div>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {solution.title}
              </h3>
              <p className="text-muted-foreground text-sm">
                {solution.description}
              </p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button 
            size="lg" 
            className="bg-gradient-primary text-primary-foreground hover:shadow-elevated transition-all duration-300"
          >
            Transform Your FMGE Preparation Today
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProblemSolutionSection;