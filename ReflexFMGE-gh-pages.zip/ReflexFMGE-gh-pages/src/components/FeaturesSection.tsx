import { 
  BookOpen, 
  Target, 
  Clock, 
  BarChart3, 
  Smartphone, 
  RefreshCw, 
  Download, 
  TrendingUp,
  CheckCircle,
  Globe
} from "lucide-react";

const FeaturesSection = () => {
  const features = [
    {
      icon: BookOpen,
      title: "Massive Question Bank",
      description: "6000+ previous year FMGE questions with detailed explanations",
      stats: "6000+ Questions"
    },
    {
      icon: Target,
      title: "Subject-wise Practice",
      description: "Organized by medical subjects (Anatomy, Physiology, Pathology, etc.)",
      stats: "19 Subjects"
    },
    {
      icon: Clock,
      title: "Mock Tests",
      description: "Full-length FMGE simulation tests matching actual exam pattern",
      stats: "Exam Pattern"
    },
    {
      icon: BarChart3,
      title: "Progress Tracking",
      description: "Monitor your improvement with detailed analytics",
      stats: "Real-time Analytics"
    },
    {
      icon: Smartphone,
      title: "Mobile + Web Access",
      description: "Study anywhere, anytime on any device",
      stats: "Cross-platform"
    },
    {
      icon: RefreshCw,
      title: "Regular Updates",
      description: "Latest exam patterns and newly released questions",
      stats: "Always Current"
    },
    {
      icon: Download,
      title: "Offline Mode",
      description: "Download questions for offline practice",
      stats: "Offline Ready"
    },
    {
      icon: TrendingUp,
      title: "Performance Analytics",
      description: "Identify weak areas and track improvement",
      stats: "Data-driven"
    }
  ];

  return (
    <section id="features" className="py-16 lg:py-24 bg-secondary/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-primary/10 text-primary border border-primary/20 mb-6">
            <CheckCircle className="w-4 h-4 mr-2" />
            <span className="text-sm font-medium">Complete FMGE Preparation Platform</span>
          </div>
          
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Everything You Need to{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Pass FMGE
            </span>
          </h2>
          
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive features designed specifically for Foreign Medical Graduates preparing for FMGE
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-card rounded-xl p-6 shadow-soft border border-border hover:shadow-card transition-all duration-300 group animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center group-hover:bg-primary/20 transition-colors duration-300">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <div className="absolute -top-2 -right-2 bg-accent text-accent-foreground text-xs px-2 py-1 rounded-full font-medium">
                  {feature.stats}
                </div>
              </div>
              
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {feature.title}
              </h3>
              
              <p className="text-muted-foreground text-sm">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Feature Highlights */}
        <div className="bg-gradient-light rounded-2xl p-8 lg:p-12 shadow-card border border-border">
          <div className="grid lg:grid-cols-3 gap-8 items-center">
            <div className="lg:col-span-2">
              <h3 className="text-2xl lg:text-3xl font-bold text-foreground mb-4">
                Why ReflexFMGE Features Are{" "}
                <span className="bg-gradient-primary bg-clip-text text-transparent">
                  Different
                </span>
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-foreground">FMGE-Specific Content</div>
                    <div className="text-muted-foreground text-sm">Unlike generic medical prep, every question is FMGE-focused</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-foreground">Proven Track Record</div>
                    <div className="text-muted-foreground text-sm">Successfully helped 50,000+ NEET PG students - same methodology</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-success mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-foreground">International Access</div>
                    <div className="text-muted-foreground text-sm">Available worldwide for students preparing abroad</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center lg:text-right">
              <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-primary rounded-full text-primary-foreground mb-4">
                <Globe className="w-12 h-12" />
              </div>
              <div className="text-3xl font-bold text-primary mb-2">50,000+</div>
              <div className="text-muted-foreground">Successful Students</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;